package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.xml.LaunchSuite.ExistingSuite;

public class Main extends Base {

	public Main(WebDriver driver) {
		super(driver);
	}

	
	
	
	// start registration
		public boolean register() throws InterruptedException {
			
			
			click(By.xpath("//a[@title='Register']"));
			return true;
		}
		
		
		// select account
				public boolean selectAccount() throws InterruptedException {
					
					
					click(By.cssSelector("#other > div.question.first-question > div"));
					click(By.xpath("//div[@class='dropdown custom-select step-one open']//li[@data-value='freelancer-or-smb'][@class='option']"));
					return true;
				}
				
	
	

}
